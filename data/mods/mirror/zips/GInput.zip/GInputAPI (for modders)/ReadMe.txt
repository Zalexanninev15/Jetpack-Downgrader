This file contains a small GInput API to be used in C++ scripts. If you have no idea what to do with
it, it probably means you don't need it at all and you can just forget about that directory ;)