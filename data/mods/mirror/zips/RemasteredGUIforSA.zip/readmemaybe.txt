#################################################
#		Remastered GUI Pack		#
#################################################

This pack has been put together to bring the updated textures from newer version of San Andreas back to the PC version, some of these textures have been
edited to fit in line with how the PC version originally displayed them and others have just been repacked with higher quality compression compared to what
was available at the time, giving an overall quality boost to the GUI if you play above 1024x768 resolution. Best used on a fresh install.

This modification is also best suited to be used with Wesser's Widescreen Fix (http://gtaforums.com/topic/669618-plugos-widescreen-hor-support/)
And SilentPatchSA (http://www.gtagarage.com/mods/show.php?id=25368), please see instructions for those mods on their respective pages.

NOTE: Fontset is ONLY for the EFIGS set of the game, if you use any other language it is reccommended to skip fonts.txd and fonts.dat

How to Install:
Drag the "models" and "data" folders to your San Andreas Install Directory, when asked if you want to replace the files, choose yes. That's it!

For STEAM users:
Right Click "Grand Theft Auto: San Andreas" > Properties > Local Files > Browse Local Files > Drag the "models" and "data" folders from the rar to here, 
choose yes when asked to replace

By Ash_735