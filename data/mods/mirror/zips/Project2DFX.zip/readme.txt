Project2DFX is a set of plugins for GTA III, Vice City, San Andreas and GTA IV(EFLC) which adds LOD corona effect to a game map, making LOD-world look a lot better. 
It also includes an open source Limit Adjuster to enhance and improve certain game limits.

Authors: ThirteenAG and TheJAMESGM

Credits: Silent, _DK, Wesser, fastman92, LINK/2012, maxorator;

Installation: Put all files inside game's root or mss(3/VC only) directory. Or unpack content of archive inside modloader folder.
For GTA IV and EFLC xliveless is required.

http://thirteenag.github.io/p2dfx
http://gtaforums.com/topic/573478-iiivcsa-project-2dfx/
http://gtaforums.com/topic/736512-iiivcsa-open-limit-adjuster/
